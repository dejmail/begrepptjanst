
#define IDI_MAIN             106
#define IDI_UPDATE           107
#define IDI_UPDATE_S         108

#define IDD_UPDATECHECK      1000
#define IDC_STATUS           1001
#define IDC_PROGRESS         1002
